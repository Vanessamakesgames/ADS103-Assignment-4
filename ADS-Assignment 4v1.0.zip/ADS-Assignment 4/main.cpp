#include <iostream>
#include "Matrix.h"
#include <time.h>




int main()
{
	Matrix mtrx;
	srand(time(NULL));
	std::cout << "\n\n\n			Hi there! Welcome to my Tic Tac Toe game!\n";
	mtrx.Assignment();
}