#pragma once
#include <cstdlib>
//#include <time.h>
#include "Matrix.h"

/*typedef */struct Move
{
	Move() {};
	Move(int Score) : score(Score) {}
	int score = NULL;
	// theMatrix[x][y]
	int x = -1; // holds value for [x] 
	int y = -1; // holds value for [y]
	Move* next = NULL;
};

class AI
{
public:
	Move* SimpleAi(TheMatrix*& pMatrix, char pChar, Move*& pMove);
	Move* HardAI(TheMatrix*& pMatrix, char pChar, Move*& pmove);
	TheMatrix* DoMove(TheMatrix*& pMatrix, Move*& pMove, char pChar);

private:
	TheMatrix* TestMove(TheMatrix*& pMatrix, int pVal, char pChar);
	bool CheckTheMatrix(TheMatrix*& pMatrix, int pValX, int pValy);
	Move* GetBestScore(Move*& pMove, int pVal);
	Move* CreateMove(int pValY, int pValX);
	Move* GetBestMove(TheMatrix*& pMatrix, Move*& pMove, int pVal, char pChar, int pVal2);
	int CheckStatus(TheMatrix*& pMatrix, char pChar);
};

