#include "Matrix.h"


int Matrix::Random() // Roll initiative!
{
	return rand() % 20 + 1; 
}

char Matrix::FirstMove(int p1Val, int p2Val, char pChar) // Sees which player goes first
{
	char temp =' ';
	char temp2 = ' ';
	if (pChar == 'X')
	{
		temp = pChar;
		temp2 = 'O';
	}
	else
	{
		temp = pChar;
		temp2 = 'X';
	}

	if (p1Val >= p2Val) return temp;
	else return temp2;
}

char Matrix::SwapTurn(char pChar)
{
	if (pChar == 'X')
	{
		return 'O';
	}
	else return 'X';
}

char Matrix::CheckGame(TheMatrix*& pMatrix) // Checks if game has been won, returns false if no winner yet
{
	if (pMatrix->display == 'X' && pMatrix->next->display == 'X' && pMatrix->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->display == 'X' && pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}
	if (pMatrix->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
	{
		return 'X';
	}

	if (pMatrix->display == 'O' && pMatrix->next->display == 'O' && pMatrix->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->display == 'O' && pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	if (pMatrix->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
	{
		return 'O';
	}
	return '/';
} 

void Matrix::Draw(TheMatrix*& pMatrix)
{
	for (int i = 0; i < 3; i++)
	{
		if (i == 0) // Printing the very top of the box
		{
			std::cout << char(topLeft);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(topWithDangles);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(topWithDangles); for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(topRight);
		}

		for (int j = 0; j < 3; j++)
		{
			std::cout << char(verticalLine);
			for (int k = 0; k < 3; k++)
			{
				PrintDisplay(pMatrix, i, k);
				std::cout << char(verticalLine);
			}
			std::cout << "\n";
		}

		if (i < 2)
		{
			std::cout << "\n" << char(leftWithDangles);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(insideDivide);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(insideDivide);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(rightWithDangles);
		}

		if (i == 2)
		{
			std::cout << char(bottomLeft);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(bottomWithDangles);
			for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(bottomWithDangles); for (int j = 0; j < 3; j++)
			{
				std::cout << char(horizontalLine);
			}
			std::cout << char(bottomRight);
		}
	}
}
// Need to add visual for win counter^^^^^^
TheMatrix* Matrix::ReceiveInput(char currentPlayer, TheMatrix*& pMatrix)
{
	char temp = ' ';
	char playerButtons = ' ';
	bool checkInput = false;
	bool whichButtons = false;

	playerButtons = pMatrix->key;
	if (playerButtons == 'A')
	{
		whichButtons = false;
	}
	else if (playerButtons == '7')
	{
		whichButtons = true;
	}

	if (whichButtons == false) // Using A->I
	{
		while (!checkInput)
		{
			std::cin >> temp;
			switch (temp)
			{
			case 'a':
				if (!pMatrix->occupied)
				{
					pMatrix->occupied = true;
					pMatrix->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'A':
				if (!pMatrix->occupied)
				{
					pMatrix->occupied = true;
					pMatrix->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'b':
				if (!pMatrix->next->occupied)
				{
					pMatrix->next->occupied = true;
					pMatrix->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'B':
				if (!pMatrix->next->occupied)
				{
					pMatrix->next->occupied = true;
					pMatrix->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'c':
				if (!pMatrix->next->next->occupied)
				{
					pMatrix->next->next->occupied = true;
					pMatrix->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'C':
				if (!pMatrix->next->next->occupied)
				{
					pMatrix->next->next->occupied = true;
					pMatrix->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'd':
				if (!pMatrix->next->next->next->occupied)
				{
					pMatrix->next->next->next->occupied = true;
					pMatrix->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'D':
				if (!pMatrix->next->next->next->occupied)
				{
					pMatrix->next->next->next->occupied = true;
					pMatrix->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'e':
				if (!pMatrix->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'E':
				if (!pMatrix->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'f':
				if (!pMatrix->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'F':
				if (!pMatrix->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'g':
				if (!pMatrix->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'G':
				if (!pMatrix->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'h':
				if (!pMatrix->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'H':
				if (!pMatrix->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'i':
				if (!pMatrix->next->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case 'I':
				if (!pMatrix->next->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			default:
				std::cout << "\n			Input was invalid, please select an available option from the screen.\n				";
			}
		}
		return;
	}
	else if (whichButtons == true) // Using numpad
	{
		while (!checkInput)
		{
			std::cin >> temp;
			switch (temp)
			{
			case '7':
				if (!pMatrix->occupied)
				{
					pMatrix->occupied = true;
					pMatrix->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '8':
				if (!pMatrix->next->occupied)
				{
					pMatrix->next->occupied = true;
					pMatrix->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '9':
				if (!pMatrix->next->next->occupied)
				{
					pMatrix->next->next->occupied = true;
					pMatrix->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '4':
				if (!pMatrix->next->next->next->occupied)
				{
					pMatrix->next->next->next->occupied = true;
					pMatrix->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '5':
				if (!pMatrix->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '6':
				if (!pMatrix->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '1':
				if (!pMatrix->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '2':
				if (!pMatrix->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			case '3':
				if (!pMatrix->next->next->next->next->next->next->next->next->occupied)
				{
					pMatrix->next->next->next->next->next->next->next->next->occupied = true;
					pMatrix->next->next->next->next->next->next->next->next->display = currentPlayer;
					checkInput = true;
				}
				else
				{
					std::cout << "\n			Input was invalid. That space is occupied, you will need to pick another.\n				";
				}
				break;
			default:
				std::cout << "\n			Input was invalid, please select an available option from the screen.\n				";
			}
		}
		return;
	}
	else
	{
		std::cout << "Error!";
		return;
	}
}

void Matrix::Assignment()
{
	StartGame();
}

bool Matrix::SetupQ1()
{
	char temp = ' ';
	bool inputCheck = false;
	std::cout << "			Would you like to (p)lay, or (w)atch two AI?\n				";
	while (inputCheck = false)
	{
		std::cin >> temp;
		switch (temp)
		{
		case 'p':
			return true;
		case 'P':
			return true;
		case 'w':
			return false;
		case 'W':
			return false;
		default:
			std::cout << "\n			Input was invalid, please press 'p' to play or 'w' to watch.\n				";
		}
	}
}

TheMatrix* Matrix::AssignKeys(TheMatrix*& pMatrix, char pChar, int counter)
{
	int i = counter;
	switch (pChar)
	{
	case 'A':
		if (i < 9)
		{
			switch (i)
			{
			case 0:
				pMatrix->display = 'A';
				pMatrix->key = 'a';
				pMatrix->key2 = 'A';
				pMatrix->x = 0;
				pMatrix->y = 0;
			case 1:
				pMatrix->display = 'B';
				pMatrix->key = 'b';
				pMatrix->key2 = 'B';
				pMatrix->x = 1;
				pMatrix->y = 0;
			case 2:
				pMatrix->display = 'C';
				pMatrix->key = 'c';
				pMatrix->key2 = 'C';
				pMatrix->x = 2;
				pMatrix->y = 0;
			case 3:
				pMatrix->display = 'D';
				pMatrix->key = 'd';
				pMatrix->key2 = 'D';
				pMatrix->x = 0;
				pMatrix->y = 1;
			case 4:
				pMatrix->display = 'E';
				pMatrix->key = 'e';
				pMatrix->key2 = 'E';
				pMatrix->x = 1;
				pMatrix->y = 1;
			case 5:
				pMatrix->display = 'F';
				pMatrix->key = 'f';
				pMatrix->key2 = 'F';
				pMatrix->x = 2;
				pMatrix->y = 1;
			case 6:
				pMatrix->display = 'G';
				pMatrix->key = 'g';
				pMatrix->key2 = 'G';
				pMatrix->x = 0;
				pMatrix->y = 2;
			case 7:
				pMatrix->display = 'H';
				pMatrix->key = 'h';
				pMatrix->key2 = 'H';
				pMatrix->x = 1;
				pMatrix->y = 2;
			case 8:
				pMatrix->display = 'I';
				pMatrix->key = 'i';
				pMatrix->key2 = 'I';
				pMatrix->x = 2;
				pMatrix->y = 2;
			}

			if (i < 8)
			{
				pMatrix->next = AssignKeys(pMatrix->next, pChar, i);
			}
			i++;
		}
		return pMatrix;
	case 'N':
		if (i < 9)
		{
			switch (i)
			{
			case 0:
				pMatrix->display = '7';
				pMatrix->key = '7';
				pMatrix->x = 0;
				pMatrix->y = 0;
			case 1:
				pMatrix->display = '8';
				pMatrix->key = '8';
				pMatrix->x = 1;
				pMatrix->y = 0;
			case 2:
				pMatrix->display = '9';
				pMatrix->key = '9';
				pMatrix->x = 2;
				pMatrix->y = 0;
			case 3:
				pMatrix->display = '4';
				pMatrix->key = '4';
				pMatrix->x = 0;
				pMatrix->y = 1;
			case 4:
				pMatrix->display = '5';
				pMatrix->key = '5';
				pMatrix->x = 1;
				pMatrix->y = 1;
			case 5:
				pMatrix->display = '6';
				pMatrix->key = '6';
				pMatrix->x = 2;
				pMatrix->y = 1;
			case 6:
				pMatrix->display = '1';
				pMatrix->key = '1';
				pMatrix->x = 0;
				pMatrix->y = 2;
			case 7:
				pMatrix->display = '2';
				pMatrix->key = '2';
				pMatrix->x = 1;
				pMatrix->y = 2;
			case 8:
				pMatrix->display = '3';
				pMatrix->key = '3';
				pMatrix->x = 2;
				pMatrix->y = 2;
			}

			if (i < 8)
			{
				pMatrix->next = AssignKeys(pMatrix->next, pChar, i);
			}
			i++;
		}
		return pMatrix;
	}
}

//bool Matrix::GetKeys(TheMatrix*& pMatrix) // Allows player to change controls at any time
//{
//	for (int i = 0; i < 3; i++)
//	{
//		for (int j = 0; j < 3; j++)
//		{
//			if (!pMatrix[i][j]->occupied) // Find first unoccupied spot in matrix
//			{
//				switch (pMatrix[i][j]->display)
//				{
//				case 'A':
//					return false;
//				case 'B':
//					return false;
//				case 'C':
//					return false;
//				case 'D':
//					return false;
//				case 'E':
//					return false;
//				case 'F':
//					return false;
//				case 'G':
//					return false;
//				case 'H':
//					return false;
//				case 'I':
//					return false;
//				case '1':
//					return true;
//				case '2':
//					return true;
//				case '3':
//					return true;
//				case '4':
//					return true;
//				case '5':
//					return true;
//				case '6':
//					return true;
//				case '7':
//					return true;
//				case '8':
//					return true;
//				case '9':
//					return true;
//				default:
//
//				}
//			}
//		}
//	}
//}

bool Matrix::SetupQ2()
{
	char temp = ' ';
	bool inputCheck = false;
	std::cout << "\n			Would you like to play another (h)uman or an (a)i?\n";
	std::cout << "				";
	while (!inputCheck)
	{
		std::cin >> temp;
		switch (temp)
		{
		case 'h':
			return true;
		case 'H':
			return true;
		case 'a':
			return false;
		case 'A':
			return false;
		default:
			std::cout << "\n			Input was invalid, please press 'h' to play a human or 'a' to play an AI.\n				";
			break;
		}
	}
}

char Matrix::SetupQ3()
{
	bool inputCheck = false;
	char input = ' ';

	std::cout << "\n			Would you like to play using the a->i keys or using the numpad? Press 'a' for a->i or 'n' for numpad.\n				";
	while (!inputCheck)
	{
		std::cin >> input;
		switch (input)
		{
		case 'a':
			return 'A';
		case 'A':
			return 'A';
		case 'n':
			return 'N';
		case 'N':
			return 'N';
		default:
			std::cout << "\n			Invalid input, please press 'a' to use the keys from a-> or 'n' to use the numpad\n				";
		}
	}
}

void Matrix::StartGame()
{
	bool gameStatus = true; // Is the game still being played
	bool quitting = false; // Does the player want to quit the game fully
	bool controls = false; // False == A->I, True == numpad
	int playerCount = -1; // Tracks how many players are playing
	char temp = ' ';
	int p1Wins = 0; // Tracks P1 wins
	int p2Wins = 0; // Tracks P2 wins
	int drawCounter = 0; // Tracks number of draws
	bool resetWins = false; // Tracks if scores need to be reset

	while (!quitting)
	{
		TheMatrix* theMatrix = new TheMatrix();
		// Does player want to use A->I or numpad
		if (p1Wins > 0 || p2Wins > 0 || drawCounter > 0)
		{
			bool inputCheck = false;
			std::cout << "			Do you want to reset the win counters? (Y)es or (N)o?\n				(Winner is announced at 5 wins)\n				";
			while (!inputCheck)
			{
				std::cin >> temp;
				switch (temp)
				{
				case 'y':
					p1Wins = 0;
					p2Wins = 0;
					drawCounter = 0;
					break;
				case 'Y':
					p1Wins = 0;
					p2Wins = 0;
					drawCounter = 0;
					break;
				case 'n':
					break;
				case 'N':
					break;
				default:
					std::cout << "\n			Invalid input, please press 'y' to reset or 'n' to continue with the current scores.\n				";
				}
			}
		}
		 
		if (!SetupQ1()) // If player wants to play or watch
		{
			playerCount = 0;
		}
		else
		{
			if (!SetupQ2()) // If player wants to play against AI
			{
				playerCount = 1;
			}
			else // If player wants to play against another human
			{
				playerCount = 2;
			}
		}
		temp = SetupQ3(); // Gets if player is using a->i or numpad
		theMatrix = AssignKeys(theMatrix, temp, 0);


		switch (playerCount)
		{
		case 0: // Watcher wants to watch
			while (gameStatus) // Will loop game mode while player wants to watch it
			{
				gameStatus = Game(0, theMatrix, p1Wins, p2Wins, drawCounter);
			}
			break;
		case 1: // Single player
			// If time, ask for AI difficulty
			while (gameStatus) // Will loop game mode while player wants to play it
			{
				gameStatus = Game(2, theMatrix, p1Wins, p2Wins, drawCounter);
			}
			break;
		case 2: // 2 player
			while (gameStatus) // Will loop game mode while player wants to play it
			{
				gameStatus = Game(1, theMatrix, p1Wins, p2Wins, drawCounter);
			}
			break;
		default: // Something went horribly wrong

		}
		//Remember to delete theMatrix

		if (!gameStatus) // If gameStatus == false, player wants to quit, true will loop back through settings
		{
			quitting = true;
		}
		/*DeleteMatrix(theMatrix);*/
	}
}

bool Matrix::Game(int pVal, TheMatrix*& pMatrix, int p1Wins, int p2Wins, int drawCounter)
{
	AI getMove;
	char currentTurn = ' '; // Keeps track of whos turn it is
	char playerOne = ' '; // Keeps track of if player one is X or O
	char playerTwo = ' '; // Keeps track or if player two is X or O
	bool playing = true; // For looping the game
	char wonYet = '/'; // Tracks if either player has won or not
	bool inputCheck = false;
	char input;
	int AI1 = -1; // First AI difficulty
	int AI2 = -1; // Second AI difficulty

	switch (pVal) // pVal = number of players
	{
	case 0: // No player // Two AI
		playerOne = 'X';
		playerTwo = 'O';

		std::cout << "\n			Do you want the first AI to be on (e)asy or (h)ard?\n				";
		while (!inputCheck)
		{
			std::cin >> input;
			switch (input)
			{
			case 'e':
				AI1 = 1;
				inputCheck = true;
				break;
			case'E':
				AI1 = 1;
				inputCheck = true;
				break;
			case 'h':
				AI1 = 2;
				inputCheck = true;
				break;
			case 'H':
				AI1 = 2;
				inputCheck = true;
				break;
			default:
				std::cout << "\n			Input was invalid, please press 'e' for easy AI or 'h' for hard AI.\n				";
			}
		}
		inputCheck = false;
		input = ' ';
		std::cout << "\n			Do you want the second AI to be on (e)asy or (h)ard?\n				";
		while (!inputCheck)
		{
			std::cin >> input;
			switch (input)
			{
			case 'e':
				AI2 = 1;
				inputCheck = true;
				break;
			case'E':
				AI2 = 1;
				inputCheck = true;
				break;
			case 'h':
				AI2 = 2;
				inputCheck = true;
				break;
			case 'H':
				AI2 = 2;
				inputCheck = true;
				break;
			default:
				std::cout << "\n			Input was invalid, please press 'e' for easy AI or 'h' for hard AI.\n				";
			}
		}

		currentTurn = FirstMove(Random(), Random(), playerOne); // Decide which player goes first

		while (playing)
		{
			Draw(pMatrix);
			wonYet = CheckGame(pMatrix); // Checks if game not won yet
			if (wonYet)
			{
				playing = false;
			}

			if (currentTurn == playerOne)
			{
				Move* bestMove = new Move();
				switch (AI1)
				{
				case 1: // Easy mode
					bestMove = getMove.SimpleAi(pMatrix, playerOne, bestMove);
					pMatrix = getMove.DoMove(pMatrix, bestMove, playerOne);
					delete bestMove;
					break;
				case 2: // Hard mode
					bestMove = getMove.HardAI(pMatrix, playerOne, bestMove);
					pMatrix = getMove.DoMove(pMatrix, bestMove, playerOne);
					delete bestMove;
					break;
				}
			}
			else
			{
				Move* bestMove = new Move();
				switch (AI1)
				{
				case 1: // Easy mode
					bestMove = getMove.SimpleAi(pMatrix, playerTwo, bestMove);
					pMatrix = getMove.DoMove(pMatrix, bestMove, playerTwo);
					delete bestMove;
					break;
				case 2: // Hard mode
					bestMove = getMove.HardAI(pMatrix, playerTwo, bestMove);
					pMatrix = getMove.DoMove(pMatrix, bestMove, playerTwo);
					delete bestMove;
					break;
				}
			}
			currentTurn = SwapTurn(currentTurn);
		}
		break;
	case 1: // 2 player
		break;
	case 2: // Single player // Check difficulty of single player
		int temp = -1; // Holds AI difficulty
		char input = ' '; // Gets players menu inputs
		bool inputCheck = false; // For looping while getting input 
		int counter = 0;
		std::cout << "			Would you like to play on (e)asy or (h)ard?\n				";
		while (!inputCheck)
		{
			std::cin >> input;
			switch (input)
			{
			case 'e':
				temp = 1;
				inputCheck = true;
				break;
			case'E':
				temp = 1;
				inputCheck = true;
				break;
			case 'h':
				temp = 2;
				inputCheck = true;
				break;
			case 'H':
				temp = 2;
				inputCheck = true;
				break;
			default:
				std::cout << "Input was invalid, please press 'e' for easy AI or 'h' for hard AI.\n				";
			}
		}
		inputCheck = false;
		input = ' ';
		// Need to decide which player goes first
		std::cout << "			Would you like to play as (X) or (O)?\n				";
		while (!inputCheck)
		{
			std::cin >> input;
			switch (input)
			{
			case 'x':
				playerOne = 'X';
				inputCheck = true;
				break;
			case 'X':
				playerOne = 'X';
				inputCheck = true;
				break;
			case 'o':
				playerOne = 'O';
				inputCheck = true;
				break;
			case 'O':
				playerOne = 'O';
				inputCheck = true;
				break;
			default:

			}
		}
		currentTurn = FirstMove(Random(), Random(), playerOne);

		while (playing)
		{
			Draw(pMatrix);
			wonYet = CheckGame(pMatrix);
			counter++;
			if (wonYet == 'X' || wonYet == 'O')
			{
				playing = false;
				if (wonYet == playerOne)
				{
					std::cout << "Congrats! You win!\n";
					p1Wins++;
					break;
				}
				else
				{
					std::cout << "AI wins this round!\n";
					p2Wins++;
					break;
				}
			}
			else if (counter == 9 && wonYet == '/') // Checks for draw
			{
				playing = false;
				break;
			}

			if (currentTurn == playerOne)
			{
				ReceiveInput(playerOne, pMatrix);
			}
			else
			{
				Move* bestMove = new Move()
				if (playerOne == 'X')
				{
					CallAI(temp, pMatrix, 'O');
				}
				else
				{
					CallAI(temp, pMatrix, 'X');
				}
			}
			currentTurn = SwapTurn(currentTurn);
		}
		break;
	default:

	}
	inputCheck = false;
	input = ' ';

	std::cout << "\n			Would you like to play with these settings again? (Y)es or (N)o?\n				"; // Does player want to play again?
	while (!inputCheck)
	{
		std::cin >> input;
		switch (input)
		{
		case 'y': // Play again
			bool temp = Game(pVal, pMatrix, p1Wins, p2Wins, drawCounter);
			return temp;
		case 'Y': // Play again
			bool temp = Game(pVal, pMatrix, p1Wins, p2Wins, drawCounter);
			return temp;
		case 'n': // Quit or change options
			bool secondInputCheck = false;
			input = ' ';
			std::cout << "\n			Would you like to (Q)uit or change (S)ettings?\n				";
			while (!secondInputCheck)
			{
				std::cin >> input;
				switch (input)
				{
				case 'q':
					return false;
				case 'Q':
					return false;
				case 's':
					return true;
				case 'S':
					return true;
				default:
					std::cout << "\n			Input was invalid, please press 'q' to quit or 's' to change settings.\n";
				}
			}
		case 'N': // Quit or change options
			bool secondInputCheck = false;
			input = ' ';
			std::cout << "\n			Would you like to (Q)uit or change (S)ettings?\n				";
			while (!secondInputCheck)
			{
				std::cin >> input;
				switch (input)
				{
				case 'q':
					return false;
				case 'Q':
					return false;
				case 's':
					return true;
				case 'S':
					return true;
				default:
					std::cout << "\n			Input was invalid, please press 'q' to quit or 's' to change settings.\n";
				}
			}
		default:
			std::cout << "\n			Input was invalid, please press 'y' to play again or 'n' to quit or change settings.\n				";
		}
	}
}

void Matrix::PrintDisplay(TheMatrix*& pMatrix, int pValY, int pValX)
{
	if (pMatrix[pValY][pValX]->occupied) // Needs to print an X or O
	{
		switch (pValX)
		{
		case 0:
			if (pMatrix[pValY][pValX]->display == 'X') // Display an X
			{
				std::cout << char(xOrO) << " " << char(xOrO);
				return;
			}
			else // Display an O
			{
				for (int i = 0; i < 3; i++)
				{
					std::cout << char(xOrO);
				}
				return;
			}
			break;
		case 1:
			if (pMatrix[pValY][pValX]->display == 'X') // Display an X
			{
				std::cout << " " << char(xOrO) << " ";
				return;
			}
			else // Display an O
			{				
				std::cout << char(xOrO) << " " << char(xOrO);
				return;
			}
			break;
		case 2:
			if (pMatrix[pValY][pValX]->display == 'X') // Display an X
			{
				std::cout << char(xOrO) << " " << char(xOrO);
				return;
			}
			else // Display an O
			{
				for (int i = 0; i < 3; i++)
				{
					std::cout << char(xOrO);
				}
				return;
			}
			break;
		default:
			std::cout << "Error!";
		}
	}
	else // Needs to show the input necessary
	{
		char temp = pMatrix[pValY][pValX]->display;
		for (int i = 0; i < 3; i++)
		{
			std::cout << temp;
		}
		return;
	}
}

//void Matrix::DeleteMatrix(TheMatrix*& pMatrix)
//{
//	for (int i = 0; i < 3; i++)
//	{
//		for (int j = 0; j < 3; j++)
//		{
//			delete pMatrix[i][j];
//		}
//	}
//	return;
//}

//void Matrix::PrintMiddle(TheMatrix* pMatrix[3][3], bool pBool, int pValY, int pValX)
//{
//	if (pMatrix[pValY][pValX]->occupied) // Needs to print an X or O
//	{
//		if (pMatrix[pValY][pValX]->display == 'X') // Display an X
//		{
//			std::cout << " " << char(xOrO) << " ";
//			return;
//		}
//		else // Display an O
//		{
//			std::cout << char(xOrO) << " " << char (xOrO);
//			return;
//		}
//	}
//	else // Needs to show the input necessary
//	{
//		for (int i = 0; i < 3; i++)
//		{
//			std::cout << pMatrix[pValY][pValX]->display;
//		}
//		return;
//	}
//}