#pragma once
#include <iostream>
//#include <time.h>
#include "AI.h"

/*typedef */struct TheMatrix
{
	bool occupied = false;
	char display = ' ';
	char key = ' ';
	char key2 = ' ';
	int x = -1;
	int y = -1;
	TheMatrix* next = NULL;
};

class Matrix
{
public:
	int Random();
	char FirstMove(int p1Val, int p2Val, char pChar);
	char SwapTurn(char pChar);
	char CheckGame(TheMatrix*& pMatrix);
	void Draw(TheMatrix*& pMatrix);
	TheMatrix* ReceiveInput( char currentPlayer, TheMatrix*& pMatrix);
	//TheMatrix theMatrix[3][3];
	void Assignment();
	bool SetupQ1(); // Play or watch
	TheMatrix* AssignKeys(TheMatrix*& pMatrix, char pChar, int counter); // Sets A->I or numpad
	//bool GetKeys(TheMatrix*& pMatrix);
	bool SetupQ2(); // Gets number of players ( #players > 0 ) + starts game
	char SetupQ3();
	void StartGame();
	// Write in second difficulty level if needed
	bool Game(int pVal, TheMatrix*& pMatrix, int p1Wins, int p2Wins, int drawCounter); 
	void PrintDisplay(TheMatrix*& pMatrix, int pValY, int pValX);
	//void DeleteMatrix(TheMatrix*& pMatrix);
	//void PrintMiddle(TheMatrix* pMatrix[3][3], bool pBool, int pValY, int pValX);
	int playerOneWins = 0;
	int playerTwoWins = 0;

protected:
	int topLeft = 201;
	int verticalLine = 205;
	int topRight = 187;
	int horizontalLine = 186;
	int topWithDangles = 203;
	int insideDivide = 206; // 4 way corner on inside
	int bottomWithDangles = 202;
	int bottomLeft = 200;
	int bottomRight = 188;
	int leftWithDangles = 204;
	int rightWithDangles = 185;
	int xOrO = 254;
};

