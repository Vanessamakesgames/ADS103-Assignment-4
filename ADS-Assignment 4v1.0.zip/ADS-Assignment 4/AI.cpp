#include "AI.h"
#include <vector>

Move* AI::SimpleAi(TheMatrix*& pMatrix, char pChar, Move*& pMove) // Gets the move for the easy AI
{
	TheMatrix* temp = pMatrix;
	bool moveMade = false;
	bool occupied = true;

	pMove->x = rand() % 3;
	pMove->y = rand() % 3;
	occupied = CheckTheMatrix(temp, pMove->x, pMove->y); // Checks if move is available, returns false if it is
	if (!occupied) // Move can be made
	{
		return pMove;
	}
	pMove = SimpleAi(temp->next, pChar, pMove);

	return pMove;
}

Move* AI::HardAI(TheMatrix*& pMatrix, char pChar, Move*& pMove)
{
	int counter = 0; // This is a counter
	pMove = GetBestMove(pMatrix, pMove, 0, pChar, counter);
	return pMove;
}

TheMatrix* AI::DoMove(TheMatrix*& pMatrix, Move*& pMove, char pChar)
{
	if (pMatrix != NULL)
	{
		if (pMatrix->x == pMove->x && pMatrix->y == pMove->y)
		{
			pMatrix->occupied = true;
			if (pChar == 'X')
			{
				pMatrix->display = 'X';
			}
			else
			{
				pMatrix->display = 'O';
			}
			return pMatrix;
		}
		
		pMatrix->next = DoMove(pMatrix->next, pMove, pChar); // Iterate through the matrix to find the right coordinates
	}
	return pMatrix;
}
// Good to go^^^^
TheMatrix* AI::TestMove(TheMatrix*& pMatrix, int pVal, char pChar) // Like DoMove, but only testing it
{
	pMatrix->occupied = true;
	if (pVal == 0) // If it is the calling AI's turn
	{
		pMatrix->display = pChar;
	}
	else if (pVal == 1)
	{
		char temp = ' ';
		if (pChar == 'X')
		{
			temp = 'O';
		}
		else
		{
			temp = 'X';
		}
		pMatrix->display = temp;
	}
	return pMatrix;
}

bool AI::CheckTheMatrix(TheMatrix*& pMatrix, int pValX, int pValY) // Check if move that easy AI is trying to do has already been done
{
	if (pMatrix != NULL)
	{
		if (pMatrix->x == pValX && pMatrix->y == pValY)
		{
			return pMatrix->occupied;			
		}
		else
		{
			return CheckTheMatrix(pMatrix->next, pValX, pValY); // Iterates through all of pMatrix to find the Matrix with the correct coordinates
		}
	}
}
// Good to go^^^^^

Move* AI::GetBestScore(Move*& pMove, int pVal)
{
	Move* temp = new Move();
	if (pVal == 0) // Calling AI - Get highest score
	{
		temp->score = pMove->score; // Placeholder for the first value
		temp->x = pMove->x;
		temp->y = pMove->y;
		while (pMove != NULL) // Iterating through moves
		{
			if (pMove->score > temp->score) // Get required values from the better move
			{
				temp->score = pMove->score;
				temp->x = pMove->x;
				temp->y = pMove->y;
			}
			if (pMove->next != NULL)
			{
				temp = GetBestScore(pMove->next, pVal);
			}
			else if (pMove->next == NULL)
			{
				return temp;
			}
		}
	}
	else if (pVal == 1) // Opponent - Get lowest score
	{
		temp->score = pMove->score; // Placeholder for the first value
		temp->x = pMove->x;
		temp->y = pMove->y;
		while (pMove != NULL) // Iterating through moves
		{
			if (pMove->score > temp->score) // Get required values from the better move
			{
				temp->score = pMove->score;
				temp->x = pMove->x;
				temp->y = pMove->y;
			}
			if (pMove->next != NULL)
			{
				temp = GetBestScore(pMove->next, pVal);
			}
			else if (pMove->next == NULL)
			{
				return temp;
			}
		}
	}
}

Move* AI::CreateMove(int pValY, int pValX)
{
	Move* temp = new Move();
	temp->score = 0;
	temp->x = pValX;
	temp->y = pValY;
	temp->next = NULL;
	return temp;
}

Move* AI::GetBestMove(TheMatrix*& pMatrix, Move*& pMove, int pVal, char pChar, int pVal2)
{
	TheMatrix* tempMatrix = pMatrix;
	Move* tempMove = pMove;
	Move* bestMove = new Move();
	int counterCopy = pVal2; // Makes a copy of the current move counter, so it can't be changed by accident

	if (tempMove == NULL)
	{
		tempMove = CreateMove(pMatrix->y, pMatrix->x);
	}
	counterCopy++;
	int tempScore = CheckStatus(tempMatrix, pChar); // Returns 0 for calling AI, and 1 for opponent
	if (tempScore == 1) // Move wins game
	{
		tempMove->score = 10;
		return tempMove;
	}
	else if (tempScore == -1) // Opponent wins game
	{
		tempMove->score = -10;
		return tempMove;
	}
	else if (tempScore == 0 && counterCopy == 9) // Game ends in draw
	{
		tempMove->score = 0;
		return tempMove;
	}

	if (!tempMatrix->occupied) // Iterate through matrix for avaiable/best spot
	{
		tempMove->x = tempMatrix->x;
		tempMove->y = tempMatrix->y;
		tempMatrix = TestMove(tempMatrix, pVal, pChar);
		if (pVal == 0) // If it is the AI that called the function
		{
			tempMove = GetBestMove(tempMatrix->next, tempMove, 1, pChar, counterCopy);
		}
		else
		{
			tempMove = GetBestMove(tempMatrix->next, tempMove, 0, pChar, counterCopy);
		}
	}
	else
	{
		tempMove = GetBestMove(tempMatrix->next, tempMove, pVal, pChar, counterCopy - 1);
	}

	if (pVal == 0) // If it is the player
	{
		bestMove = GetBestScore(tempMove, pVal);
	}
	else
	{
		bestMove = GetBestScore(tempMove, pVal);
	}
	return bestMove;
}

int AI::CheckStatus(TheMatrix*& pMatrix, char pChar) // Checks whether win condition for game has been met
{
	if (pChar == 'X')
	{
		if (pMatrix->display == 'X' && pMatrix->next->display == 'X' && pMatrix->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->display == 'X' && pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X')
		{
			return 1;
		}
		if (pMatrix->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return 1;
		}

		if (pMatrix->display == 'O' && pMatrix->next->display == 'O' && pMatrix->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->display == 'O' && pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		if (pMatrix->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return -1;
		}
		return 0;
	}
	else if (pChar == 'O')
	{
		if (pMatrix->display == 'X' && pMatrix->next->display == 'X' && pMatrix->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->display == 'X' && pMatrix->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->next->display == 'X' && pMatrix->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->display == 'X')
		{
			return -1;
		}
		if (pMatrix->next->next->display == 'X' && pMatrix->next->next->next->next->next->display == 'X' && pMatrix->next->next->next->next->next->next->next->next->display == 'X')
		{
			return -1;
		}

		if (pMatrix->display == 'O' && pMatrix->next->display == 'O' && pMatrix->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->next->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->display == 'O' && pMatrix->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->next->display == 'O' && pMatrix->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		if (pMatrix->next->next->display == 'O' && pMatrix->next->next->next->next->next->display == 'O' && pMatrix->next->next->next->next->next->next->next->next->display == 'O')
		{
			return 1;
		}
		return 0;
	}
}
// Good to go^^^^